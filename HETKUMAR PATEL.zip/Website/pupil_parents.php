<?php 
include 'db.php'; 

// Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM Pupil_Parents WHERE id = $id");
    header("Location: pupil_parents.php");
    exit;
}

// Insert
if (isset($_POST['insert'])) {
    $pupil_id = $_POST['pupil_id'];
    $parent_id = $_POST['parent_id'];
    $conn->query("INSERT INTO Pupil_Parents (pupil_id, parent_id) VALUES ($pupil_id, $parent_id)");
    header("Location: pupil_parents.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pupil-Parents</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<h2>Pupil-Parent Relationships</h2>

<table border="1">
    <tr><th>ID</th><th>Pupil</th><th>Parent</th><th>Actions</th></tr>
    <?php
    $res = $conn->query("SELECT PP.pupil_id, Pupils.name AS pupil_name, Parents.name AS parent_name 
                         FROM Pupil_Parents PP 
                         JOIN Pupils ON PP.pupil_id = Pupils.pupil_id 
                         JOIN Parents ON PP.parent_id = Parents.parent_id");
    while ($row = $res->fetch_assoc()) {
        echo "<tr>
            <td>{$row['pupil_id']}</td>
            <td>{$row['pupil_name']}</td>
            <td>{$row['parent_name']}</td>
            <td><a href='pupil_parents.php?delete={$row['pupil_id']}' onclick='return confirm(\"Delete this link?\")'>Delete</a></td>
        </tr>";
    }
    ?>
</table>

<h3>Link Pupil to Parent</h3>
<form method="POST">
    <select name="pupil_id" required>
        <option value="">Select Pupil</option>
        <?php
        $pupils = $conn->query("SELECT * FROM Pupils");
        while ($p = $pupils->fetch_assoc()) {
            echo "<option value='{$p['pupil_id']}'>{$p['name']}</option>";
        }
        ?>
    </select>

    <select name="parent_id" required>
        <option value="">Select Parent</option>
        <?php
        $parents = $conn->query("SELECT * FROM Parents");
        while ($p = $parents->fetch_assoc()) {
            echo "<option value='{$p['parent_id']}'>{$p['name']}</option>";
        }
        ?>
    </select>

    <button type="submit" name="insert">Link</button>
</form>
</body>
</html>
