CREATE DATABASE StAlphonsusSchool;
USE StAlphonsusSchool;

-- Classes Table
CREATE TABLE Classes (
    class_id INT AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(50) NOT NULL UNIQUE,
    capacity INT NOT NULL
);

-- Teachers Table
CREATE TABLE Teachers (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(15) NOT NULL,
    annual_salary DECIMAL(10,2) NOT NULL,
    background_check BOOLEAN NOT NULL,
    class_id INT UNIQUE,  -- Ensures a teacher can only teach one class
    FOREIGN KEY (class_id) REFERENCES Classes(class_id) ON DELETE SET NULL
);

-- Parents/Guardians Table
CREATE TABLE Parents (
    parent_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL
);

-- Pupils Table
CREATE TABLE Pupils (
    pupil_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    medical_info TEXT,
    class_id INT,
    FOREIGN KEY (class_id) REFERENCES Classes(class_id) ON DELETE SET NULL
);

-- Pupils-Parents Relationship Table (Many-to-Many)
CREATE TABLE Pupil_Parents (
    pupil_id INT,
    parent_id INT,
    PRIMARY KEY (pupil_id, parent_id),
    FOREIGN KEY (pupil_id) REFERENCES Pupils(pupil_id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES Parents(parent_id) ON DELETE CASCADE
);

INSERT INTO Classes (class_name, capacity) VALUES
('Reception Year', 30),
('Year One', 30),
('Year Two', 30),
('Year Three', 30),
('Year Four', 30),
('Year Five', 30),
('Year Six', 30);

INSERT INTO Teachers (name, address, phone, annual_salary, background_check, class_id) VALUES
('Alice Johnson', '123 School Lane, Luton', '07411223344', 32000.00, TRUE, 1),
('Bob Smith', '45 Green Road, Luton', '07455667788', 34000.00, TRUE, 2),
('Catherine Brown', '67 Elm Street, Luton', '07333444556', 35000.00, TRUE, 3),
('Daniel White', '89 Pine Ave, Luton', '07788990011', 36000.00, TRUE, 4),
('Emma Wilson', '22 Oak Drive, Luton', '07881112233', 37000.00, TRUE, 5);


INSERT INTO Parents (name, address, email, phone) VALUES
('Michael Green', '12 Park Street, Luton', 'michael.green@example.com', '07123456789'),
('Sarah Adams', '34 High Road, Luton', 'sarah.adams@example.com', '07234567890'),
('David Lee', '56 Lake View, Luton', 'david.lee@example.com', '07345678901'),
('Laura White', '78 Maple Crescent, Luton', 'laura.white@example.com', '07456789012'),
('James Brown', '90 Birch Lane, Luton', 'james.brown@example.com', '07567890123');


INSERT INTO Pupils (name, address, medical_info, class_id) VALUES
('Liam Green', '12 Park Street, Luton', 'Peanut allergy', 1),
('Olivia Adams', '34 High Road, Luton', 'Asthma', 2),
('Noah Lee', '56 Lake View, Luton', 'None', 3),
('Emma White', '78 Maple Crescent, Luton', 'Diabetic', 4),
('James Brown Jr.', '90 Birch Lane, Luton', 'None', 5);


INSERT INTO Pupil_Parents (pupil_id, parent_id) VALUES
(1, 1),  
(2, 2),  
(3, 3),  
(4, 4),  
(5, 5);  

