<?php 
include 'db.php'; 

// Handle delete request
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $conn->query("DELETE FROM Classes WHERE class_id = $delete_id");
    header("Location: classes.php"); // Refresh to avoid resubmission
    exit;
}

// Handle update request
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $class_name = $_POST['class_name'];
    $capacity = $_POST['capacity'];
    $conn->query("UPDATE Classes SET class_name = '$class_name', capacity = $capacity WHERE class_id = $id");
    header("Location: classes.php");
    exit;
}

// Handle insert request
if (isset($_POST['insert'])) {
    $class_name = $_POST['class_name'];
    $capacity = $_POST['capacity'];
    $conn->query("INSERT INTO Classes (class_name, capacity) VALUES ('$class_name', $capacity)");
    header("Location: classes.php");
    exit;
}

// Fetch data for edit if needed
$edit_data = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $result = $conn->query("SELECT * FROM Classes WHERE class_id = $edit_id");
    $edit_data = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Classes</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <h2>Classes List</h2>
    <table border="1">
        <tr><th>ID</th><th>Name</th><th>Capacity</th><th>Actions</th></tr>
        <?php
        $result = $conn->query("SELECT * FROM Classes");
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['class_id']}</td>
                    <td>{$row['class_name']}</td>
                    <td>{$row['capacity']}</td>
                    <td>
                        <a href='classes.php?edit={$row['class_id']}'>Edit</a> | 
                        <a href='classes.php?delete={$row['class_id']}' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                    </td>
                </tr>";
        }
        ?>
    </table>

    <h3><?php echo $edit_data ? "Edit Class" : "Add New Class"; ?></h3>
    <form method="POST">
        <input type="hidden" name="id" value="<?= $edit_data['class_id'] ?? '' ?>">
        <input type="text" name="class_name" placeholder="Class Name" required value="<?= $edit_data['class_name'] ?? '' ?>">
        <input type="number" name="capacity" placeholder="Capacity" required value="<?= $edit_data['capacity'] ?? '' ?>">
        <button type="submit" name="<?= $edit_data ? 'update' : 'insert' ?>">
            <?= $edit_data ? 'Update' : 'Add' ?>
        </button>
        <?php if ($edit_data): ?>
            <a href="classes.php"><button type="button">Cancel</button></a>
        <?php endif; ?>
    </form>
</body>
</html>
