<?php 
include 'db.php'; 

// Delete
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM Teachers WHERE teacher_id = " . $_GET['delete']);
    header("Location: teachers.php");
    exit;
}

// Update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $sql = "UPDATE Teachers SET name='{$_POST['name']}', address='{$_POST['address']}', phone='{$_POST['phone']}', 
            annual_salary={$_POST['salary']}, background_check=" . (isset($_POST['background_check']) ? 1 : 0) . ", 
            class_id={$_POST['class_id']} WHERE teacher_id=$id";
    $conn->query($sql);
    header("Location: teachers.php");
    exit;
}

// Insert
if (isset($_POST['insert'])) {
    $sql = "INSERT INTO Teachers (name, address, phone, annual_salary, background_check, class_id) VALUES (
        '{$_POST['name']}', '{$_POST['address']}', '{$_POST['phone']}', {$_POST['salary']}, 
        " . (isset($_POST['background_check']) ? 1 : 0) . ", {$_POST['class_id']})";
    $conn->query($sql);
    header("Location: teachers.php");
    exit;
}

// Edit data
$edit_data = null;
if (isset($_GET['edit'])) {
    $res = $conn->query("SELECT * FROM Teachers WHERE teacher_id = " . $_GET['edit']);
    $edit_data = $res->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Teachers</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<h2>Teachers</h2>
<table border="1">
    <tr><th>ID</th><th>Name</th><th>Phone</th><th>Salary</th><th>Background Check</th><th>Class</th><th>Actions</th></tr>
    <?php
    $res = $conn->query("SELECT Teachers.*, Classes.class_name FROM Teachers LEFT JOIN Classes ON Teachers.class_id = Classes.class_id");
    while ($row = $res->fetch_assoc()) {
        echo "<tr>
            <td>{$row['teacher_id']}</td><td>{$row['name']}</td><td>{$row['phone']}</td>
            <td>{$row['annual_salary']}</td><td>" . ($row['background_check'] ? 'Yes' : 'No') . "</td>
            <td>{$row['class_name']}</td>
            <td><a href='teachers.php?edit={$row['teacher_id']}'>Edit</a> | 
                <a href='teachers.php?delete={$row['teacher_id']}' onclick='return confirm(\"Delete this?\")'>Delete</a></td>
        </tr>";
    }
    ?>
</table>

<h3><?= $edit_data ? "Edit" : "Add" ?> Teacher</h3>
<form method="POST">
    <input type="hidden" name="id" value="<?= $edit_data['teacher_id'] ?? '' ?>">
    <input type="text" name="name" placeholder="Name" required value="<?= $edit_data['name'] ?? '' ?>">
    <input type="text" name="address" placeholder="Address" required value="<?= $edit_data['address'] ?? '' ?>">
    <input type="text" name="phone" placeholder="Phone" required value="<?= $edit_data['phone'] ?? '' ?>">
    <input type="number" step="0.01" name="salary" placeholder="Salary" required value="<?= $edit_data['annual_salary'] ?? '' ?>">
    <label><input type="checkbox" name="background_check" <?= isset($edit_data) && $edit_data['background_check'] ? 'checked' : '' ?>> Background Check</label>
    <select name="class_id" required>
        <option value="">Select Class</option>
        <?php
        $classes = $conn->query("SELECT * FROM Classes");
        while ($c = $classes->fetch_assoc()) {
            $selected = isset($edit_data) && $edit_data['class_id'] == $c['class_id'] ? 'selected' : '';
            echo "<option value='{$c['class_id']}' $selected>{$c['class_name']}</option>";
        }
        ?>
    </select>
    <button type="submit" name="<?= $edit_data ? 'update' : 'insert' ?>"><?= $edit_data ? 'Update' : 'Add' ?></button>
    <?php if ($edit_data): ?><a href="teachers.php"><button type="button">Cancel</button></a><?php endif; ?>
</form>
</body>
</html>
