<?php 
include 'db.php'; 

if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM Pupils WHERE pupil_id = " . $_GET['delete']);
    header("Location: pupils.php");
    exit;
}

if (isset($_POST['update'])) {
    $sql = "UPDATE Pupils SET name='{$_POST['name']}', address='{$_POST['address']}', medical_info='{$_POST['medical_info']}', class_id={$_POST['class_id']} WHERE pupil_id={$_POST['id']}";
    $conn->query($sql);
    header("Location: pupils.php");
    exit;
}

if (isset($_POST['insert'])) {
    $sql = "INSERT INTO Pupils (name, address, medical_info, class_id) VALUES ('{$_POST['name']}', '{$_POST['address']}', '{$_POST['medical_info']}', {$_POST['class_id']})";
    $conn->query($sql);
    header("Location: pupils.php");
    exit;
}

$edit_data = null;
if (isset($_GET['edit'])) {
    $res = $conn->query("SELECT * FROM Pupils WHERE pupil_id = " . $_GET['edit']);
    $edit_data = $res->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head><title>Pupils</title><link rel="stylesheet" href="styles.css"></head>
<body>
<?php include 'navbar.php'; ?>
<h2>Pupils</h2>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Medical Info</th><th>Class</th><th>Actions</th></tr>
<?php
$res = $conn->query("SELECT Pupils.*, Classes.class_name FROM Pupils LEFT JOIN Classes ON Pupils.class_id = Classes.class_id");
while ($row = $res->fetch_assoc()) {
    echo "<tr><td>{$row['pupil_id']}</td><td>{$row['name']}</td><td>{$row['medical_info']}</td><td>{$row['class_name']}</td>
    <td><a href='pupils.php?edit={$row['pupil_id']}'>Edit</a> | 
        <a href='pupils.php?delete={$row['pupil_id']}' onclick='return confirm(\"Delete this?\")'>Delete</a></td></tr>";
}
?>
</table>

<h3><?= $edit_data ? "Edit" : "Add" ?> Pupil</h3>
<form method="POST">
    <input type="hidden" name="id" value="<?= $edit_data['pupil_id'] ?? '' ?>">
    <input type="text" name="name" placeholder="Name" required value="<?= $edit_data['name'] ?? '' ?>">
    <input type="text" name="address" placeholder="Address" required value="<?= $edit_data['address'] ?? '' ?>">
    <input type="text" name="medical_info" placeholder="Medical Info" required value="<?= $edit_data['medical_info'] ?? '' ?>">
    <select name="class_id" required>
        <option value="">Select Class</option>
        <?php
        $classes = $conn->query("SELECT * FROM Classes");
        while ($c = $classes->fetch_assoc()) {
            $selected = isset($edit_data) && $edit_data['class_id'] == $c['class_id'] ? 'selected' : '';
            echo "<option value='{$c['class_id']}' $selected>{$c['class_name']}</option>";
        }
        ?>
    </select>
    <button type="submit" name="<?= $edit_data ? 'update' : 'insert' ?>"><?= $edit_data ? 'Update' : 'Add' ?></button>
    <?php if ($edit_data): ?><a href="pupils.php"><button type="button">Cancel</button></a><?php endif; ?>
</form>
</body>
</html>
