<?php 
include 'db.php'; 

if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM Parents WHERE parent_id = " . $_GET['delete']);
    header("Location: parents.php");
    exit;
}

if (isset($_POST['update'])) {
    $conn->query("UPDATE Parents SET name='{$_POST['name']}', address='{$_POST['address']}', email='{$_POST['email']}', phone='{$_POST['phone']}' WHERE parent_id={$_POST['id']}");
    header("Location: parents.php");
    exit;
}

if (isset($_POST['insert'])) {
    $conn->query("INSERT INTO Parents (name, address, email, phone) VALUES ('{$_POST['name']}', '{$_POST['address']}', '{$_POST['email']}', '{$_POST['phone']}')");
    header("Location: parents.php");
    exit;
}

$edit_data = null;
if (isset($_GET['edit'])) {
    $res = $conn->query("SELECT * FROM Parents WHERE parent_id = " . $_GET['edit']);
    $edit_data = $res->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head><title>Parents</title><link rel="stylesheet" href="styles.css"></head>
<body>
<?php include 'navbar.php'; ?>
<h2>Parents</h2>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Actions</th></tr>
<?php
$res = $conn->query("SELECT * FROM Parents");
while ($row = $res->fetch_assoc()) {
    echo "<tr>
    <td>{$row['parent_id']}</td><td>{$row['name']}</td><td>{$row['email']}</td><td>{$row['phone']}</td>
    <td><a href='parents.php?edit={$row['parent_id']}'>Edit</a> | 
        <a href='parents.php?delete={$row['parent_id']}' onclick='return confirm(\"Delete this?\")'>Delete</a></td></tr>";
}
?>
</table>

<h3><?= $edit_data ? "Edit" : "Add" ?> Parent</h3>
<form method="POST">
    <input type="hidden" name="id" value="<?= $edit_data['parent_id'] ?? '' ?>">
    <input type="text" name="name" placeholder="Name" required value="<?= $edit_data['name'] ?? '' ?>">
    <input type="text" name="address" placeholder="Address" required value="<?= $edit_data['address'] ?? '' ?>">
    <input type="email" name="email" placeholder="Email" required value="<?= $edit_data['email'] ?? '' ?>">
    <input type="text" name="phone" placeholder="Phone" required value="<?= $edit_data['phone'] ?? '' ?>">
    <button type="submit" name="<?= $edit_data ? 'update' : 'insert' ?>"><?= $edit_data ? 'Update' : 'Add' ?></button>
    <?php if ($edit_data): ?><a href="parents.php"><button type="button">Cancel</button></a><?php endif; ?>
</form>
</body>
</html>
