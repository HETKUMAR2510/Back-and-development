<nav>
    <a href="index.php">Home</a>
    <a href="classes.php">Classes</a>
    <a href="teachers.php">Teachers</a>
    <a href="parents.php">Parents</a>
    <a href="pupils.php">Pupils</a>
    <a href="pupil_parents.php">Pupil-Parents</a>
</nav>
<hr>
